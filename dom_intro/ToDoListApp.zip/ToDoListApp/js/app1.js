
const toDoList = []; //This is an array going to store the objects
const doneList = []; //This is an array to store done list objects

class toDo {

  constructor(toDoItem, completeButton){
     
  }
}


$('form').on('submit', (event) => {
  console.log( $('#input-box').val() );
  toDoList.push( $('#input-box').val() );
  event.preventDefault();
  $(event.currentTarget).trigger('reset');

  render();
});
