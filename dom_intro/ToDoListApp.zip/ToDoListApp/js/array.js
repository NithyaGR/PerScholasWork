var arr = [12,24,56];

var arr1Splice = arr.splice(2,1);
console.log(arr1Splice);
console.log(arr);

console.log(arr.splice(0,1));
console.log(arr1Splice);
console.log(arr);
